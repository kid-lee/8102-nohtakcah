import cv2
import os
import matplotlib
import face_recognition
import numpy as np
# os.chdir('/Users/jkovarski/Documents')
# vidcap = cv2.VideoCapture('video1.mp4')
# success,image = vidcap.read()
# count = 0

# def videoLoading(startFrame,endFrame) :
#     for i in range(startFrame,endFrame) :
#       #cv2.imwrite("frame%d.jpg" % count, image)     # save frame as JPEG file
#           success,image = vidcap.read()
#           cv2.imshow('image',image)
#           print('Read a new frame: ', success)
#
# videoLoading(1,60)

os.chdir('/Users/jkovarski/Documents/cruzers/datasets')
img = cv2.imread('Angelina Jolie/3.jpeg')
cv2.imshow('img',img)
cv2.waitKey(0)
cv2.destroyAllWindows()
