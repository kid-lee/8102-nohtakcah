# coding: utf-8
import numpy as np
import pandas as pd
from keras.preprocessing import image
from os.path import join
import matplotlib.pyplot as plt
import argparse
from PIL import Image
import scipy.misc

import os

# construct the argument parser and parse the arguments
ap = argparse.ArgumentParser()
ap.add_argument("-d", "--data_dir", required=True,
        help="path to data_dir")
ap.add_argument("-o", "--output", type=str,
        help="path to output folder")
ap.add_argument("-n", "--name", type=str,
        help="name of the actor")

args = vars(ap.parse_args())


data_path = args["data_dir"]
output_folder = args["output"]
actor_name = args["name"]


input_size = 512
np.random.seed(1987)


def get_image(img_name):
    """
    Getting image from the desk
    :param img_name: name of the image
    :return: returns a normalized version of the image
    """
    img = image.load_img(join(img_name),
                         target_size=(input_size, input_size))
    img = image.img_to_array(img)
    img = img / 255.
    return img


def plot_img(img):
    """
    Ploting given image
    :param img: image matrix
    """
    fig, axs = plt.subplots(ncols=2, figsize=(10, 5), sharex=True, sharey=True)
    axs[0].imshow(img)
    for ax in axs:
        ax.set_xlim(0, input_size)
        ax.axis('off')
    fig.tight_layout()
    plt.show()


def plot_img_transformed(img, img_tr):
    """
    Plotiing transformed image
    :param img: original image
    :param img_tr: transformed image
    """
    fig, axs = plt.subplots(ncols=2, figsize=(16, 4), sharex=True, sharey=True)
    axs[0].imshow(img)
    axs[1].imshow(img_tr)
    for ax in axs:
        ax.set_xlim(0, input_size)
        ax.axis('off')
    fig.tight_layout()
    plt.show()


def flip_axis(x, axis):
    """
    Flipping the axis of a given image
    :param x: image data
    :param axis: axis to flip based on
    :return: flipped version of x based on the given axis
    """
    x = np.asarray(x).swapaxes(axis, 0)
    x = x[::-1, ...]
    x = x.swapaxes(0, axis)
    return x


def random_flip(img, u=0.5):
    """
    Flipping an image
    :param img: image data
    :param u: angle
    :return: Flipped image
    """
    if np.random.random() < u:
        img = flip_axis(img, 1)
    return img


def rotate(x, theta, row_axis=0, col_axis=1, channel_axis=2, fill_mode='nearest', cval=0.):
    """
    Rotating an image
    :param x:
    :param theta:
    :param row_axis:
    :param col_axis:
    :param channel_axis:
    :param fill_mode:
    :param cval:
    :return:
    """
    rotation_matrix = np.array([[np.cos(theta), -np.sin(theta), 0],
                                [np.sin(theta), np.cos(theta), 0],
                                [0, 0, 1]])
    h, w = x.shape[row_axis], x.shape[col_axis]
    transform_matrix = image.transform_matrix_offset_center(rotation_matrix, h, w)
    x = image.apply_transform(x, transform_matrix, channel_axis, fill_mode, cval)
    return x


def random_rotate(img, rotate_limit=(-20, 20), u=0.5):
    """
    random rotation of an image
    :param img:
    :param rotate_limit:
    :param u:
    :return:
    """
    if np.random.random() < u:
        theta = np.pi / 180 * np.random.uniform(rotate_limit[0], rotate_limit[1])
        img = rotate(img, theta)
    return img


def shift(x, wshift, hshift, row_axis=0, col_axis=1, channel_axis=2, fill_mode='nearest', cval=0.):
    """
    shift given image
    :param x:
    :param wshift:
    :param hshift:
    :param row_axis:
    :param col_axis:
    :param channel_axis:
    :param fill_mode:
    :param cval:
    :return:
    """
    h, w = x.shape[row_axis], x.shape[col_axis]
    tx = hshift * h
    ty = wshift * w
    translation_matrix = np.array([[1, 0, tx],
                                   [0, 1, ty],
                                   [0, 0, 1]])
    transform_matrix = translation_matrix  # no need to do offset
    x = image.apply_transform(x, transform_matrix, channel_axis, fill_mode, cval)
    return x


def random_shift(img, w_limit=(-0.1, 0.1), h_limit=(-0.1, 0.1), u=0.5):
    """
    Random shifting of the image
    :param img:
    :param w_limit:
    :param h_limit:
    :param u:
    :return:
    """
    if np.random.random() < u:
        wshift = np.random.uniform(w_limit[0], w_limit[1])
        hshift = np.random.uniform(h_limit[0], h_limit[1])
        img = shift(img, wshift, hshift)
    return img


def zoom(x, zx, zy, row_axis=0, col_axis=1, channel_axis=2, fill_mode='nearest', cval=0.):
    """
    Zooming the image
    :param x:
    :param zx:
    :param zy:
    :param row_axis:
    :param col_axis:
    :param channel_axis:
    :param fill_mode:
    :param cval:
    :return:
    """
    zoom_matrix = np.array([[zx, 0, 0],
                            [0, zy, 0],
                            [0, 0, 1]])
    h, w = x.shape[row_axis], x.shape[col_axis]
    transform_matrix = image.transform_matrix_offset_center(zoom_matrix, h, w)
    x = image.apply_transform(x, transform_matrix, channel_axis, fill_mode, cval)
    return x


def random_zoom(img, zoom_range=(0.8, 1), u=0.5):
    """
    Random zoom
    :param img:
    :param zoom_range:
    :param u:
    :return:
    """
    if np.random.random() < u:
        zx, zy = np.random.uniform(zoom_range[0], zoom_range[1], 2)
        img = zoom(img, zx, zy)
    return img


def shear(x, shear, row_axis=0, col_axis=1, channel_axis=2, fill_mode='nearest', cval=0.):
    """
    Applying shearing transfo
    :param x:
    :param shear:
    :param row_axis:
    :param col_axis:
    :param channel_axis:
    :param fill_mode:
    :param cval:
    :return:
    """
    shear_matrix = np.array([[1, -np.sin(shear), 0],
                             [0, np.cos(shear), 0],
                             [0, 0, 1]])
    h, w = x.shape[row_axis], x.shape[col_axis]
    transform_matrix = image.transform_matrix_offset_center(shear_matrix, h, w)
    x = image.apply_transform(x, transform_matrix, channel_axis, fill_mode, cval)
    return x


def random_shear(img, intensity_range=(-0.5, 0.5), u=0.5):
    if np.random.random() < u:
        sh = np.random.uniform(-intensity_range[0], intensity_range[1])
        img = shear(img, sh)
    return img


def random_channel_shift(x, limit, channel_axis=2):
    x = np.rollaxis(x, channel_axis, 0)
    min_x, max_x = np.min(x), np.max(x)
    channel_images = [np.clip(x_ch + np.random.uniform(-limit, limit), min_x, max_x) for x_ch in x]
    x = np.stack(channel_images, axis=0)
    x = np.rollaxis(x, 0, channel_axis + 1)
    return x


def random_gray(img, u=0.5):
    if np.random.random() < u:
        coef = np.array([[[0.114, 0.587, 0.299]]])  # rgb to gray (YCbCr)
        gray = np.sum(img * coef, axis=2)
        img = np.dstack((gray, gray, gray))
    return img


def random_contrast(img, limit=(-0.3, 0.3), u=0.5):
    if np.random.random() < u:
        alpha = 1.0 + np.random.uniform(limit[0], limit[1])
        coef = np.array([[[0.114, 0.587, 0.299]]])  # rgb to gray (YCbCr)
        gray = img * coef
        gray = (3.0 * (1.0 - alpha) / gray.size) * np.sum(gray)
        img = alpha * img + gray
        img = np.clip(img, 0., 1.)
    return img


def random_brightness(img, limit=(-0.3, 0.3), u=0.5):
    if np.random.random() < u:
        alpha = 1.0 + np.random.uniform(limit[0], limit[1])
        img = alpha * img
        img = np.clip(img, 0., 1.)
    return img


def random_saturation(img, limit=(-0.3, 0.3), u=0.5):
    if np.random.random() < u:
        alpha = 1.0 + np.random.uniform(limit[0], limit[1])
        coef = np.array([[[0.114, 0.587, 0.299]]])
        gray = img * coef
        gray = np.sum(gray, axis=2, keepdims=True)
        img = alpha * img + (1. - alpha) * gray
        img = np.clip(img, 0., 1.)
    return img


def random_augmentation(img):
    img = random_channel_shift(img, limit=0.05)
    img = random_brightness(img, limit=(-0.5, 0.5), u=0.5)
    img = random_contrast(img, limit=(-0.5, 0.5), u=0.5)
    img = random_saturation(img, limit=(-0.5, 0.5), u=0.5)
    img = random_gray(img, u=0.2)
    img = random_rotate(img, rotate_limit=(-20, 20), u=0.5)
    img = random_shear(img, intensity_range=(-0.3, 0.3), u=0.2)
    img = random_flip(img, u=0.3)
    img = random_shift(img, w_limit=(-0.1, 0.1), h_limit=(-0.1, 0.1), u=0.3)
    img = random_zoom(img, zoom_range=(0.8, 1), u=0.3)
    return img


img_file_names = os.listdir(data_path)

j = 0
for img_name in img_file_names:
    img = get_image(os.path.join(data_path, img_name))

    for i in range(30):
        j += 1
        img_aug = random_augmentation(img)
        scipy.misc.imsave(output_folder+'/' + actor_name + '_' + str(i) + str(j) + '.jpg', img_aug)
