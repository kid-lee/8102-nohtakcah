import argparse
import pickle
import time, os
START_TS = time.time()  # Time the file processing started
"""
How to use it the script:
/home/hackathon-2018-team-11/ahmed/face-recognition-opencv
conda activate py35
python final_recognize_faces_video_file.py --encodings encodings_tom.pickle -i /home/hackathon-2018-team-11/remi/video1.mp4 -f 6 -w 3

The code is currently using all CPUs and all GPUs in parallel.
CPU is still the bottleneck. For further performance improvements, we should look at
moving some of that computation to the GPU, like video decoding.

The main thread is decoding the input video file, and handing over batch of frames to the workers (multi-process).
"""

# Command line parsing
ap = argparse.ArgumentParser()
ap.add_argument("-e", "--encodings", required=True,
    help="path to serialized db of facial encodings")
ap.add_argument("-w", "--workers", required=True, default = 1, type=int,
    help="Number of process workers")
ap.add_argument("-i", "--input", required=True,
    help="path to input video")
ap.add_argument("-d", "--detection-method", type=str, default="cnn",
    help="face detection model to use: either `hog` or `cnn`")
ap.add_argument("-f", "--frameskip", dest="frameskip", type=int, default=0,
    help="Frames to skip")
args = vars(ap.parse_args())



def do_work(worker_index, queue):
    """
    Code executed by the workers that do image processing
    Each worker writes its own CSV file. They will all get merged later.
    """
    import os
    gpu_index = str(worker_index % 2)
    # We try to assign a different GPU to all workers to parallelize GPU usage
    print("Setting cuda device to", gpu_index)
    os.environ["CUDA_VISIBLE_DEVICES"] = gpu_index

    import face_recognition
    import imutils
    from multiprocessing import Process, Queue
    import pickle
    import time
    import cv2
    f = open("output_worker_" + str(worker_index) + ".csv", "w")

    # load the known faces and embeddings
    print("[INFO] loading encodings...")
    data = pickle.loads(open(args["encodings"], "rb").read())

    ## Read from the queue
    while True:
        items = queue.get()
        print("Worker", worker_index, "got a new item")
        if items == 'DONE':
            print("Worker", worker_index, "finished!!!!")
            break

        try:
            # detect the (x, y)-coordinates of the bounding boxes
            # corresponding to each face in the input frame, then compute
            # the facial embeddings for each face
            # model=args["detection_method"] ?????
            print("Processing batches of", len(items), "frames")
            batch_of_face_locations = face_recognition.batch_face_locations([ frame for (frame_index, ms, frame) in items ], number_of_times_to_upsample=0)

            # Detect face locations in batches
            for (frame_index, ms, frame), face_locations in zip(items, batch_of_face_locations):
                encodings = face_recognition.face_encodings(frame, face_locations)

                # loop over the facial embeddings
                found = False
                for encoding in encodings:
                    # attempt to match each face in the input image to our known
                    # encodings
                    matches = face_recognition.compare_faces(data["encodings"], encoding)

                    # check to see if we have found a match
                    if True in matches:
                        found = True

                # print(str(frame_index) + "," + str(int(found)) + "," + str(ms))
                f.write(str(frame_index) + "," + str(int(found)) + "," + str(ms) + "\n")
                f.flush()
        except Exception as ex:
            print("!!! Received exception", ex)
    f.close()


# Remove all CSV files in cwd
for file_name in os.listdir("."):
    if file_name.endswith(".csv"):
        print("Removing file name", file_name)
        os.remove(file_name)

# Spawn some workers in new processes to parallelize CPU/GPU usage
from multiprocessing import Process, Queue
pqueue = Queue()
workers = [ Process(target=do_work, args=(worker_index,pqueue)) for worker_index in range(args['workers']) ]
for worker in workers:
    worker.daemon = True
    worker.start()        # Launch do_work() as a separate python process



import face_recognition
import imutils
import cv2
print("Setting cuda device to 1")
os.environ["CUDA_VISIBLE_DEVICES"]="1"

# Initialize the pointer to the video file and the video writer
# TODO: Decoding the input video does not use the GPU
print("[INFO] processing video...")
stream = cv2.VideoCapture(args["input"])


# loop over frames from the video file stream
shape = None
frames_batch = []
frame_index = -1
while True:
    # grab the next frame
    (grabbed, frame) = stream.read()
    frame_index += 1
    #print(frame_index)

    if not grabbed:
        # Reached end of file
        print("Reached end of file!")
        break

    # Frame skip to speed up video processing
    if frame_index % (args['frameskip']) != 0:
        continue

    ms = stream.get(cv2.CAP_PROP_POS_MSEC)

    # if not(frame_index > 3200 and frame_index < 3300):
    #    continue

    # resize the input it to have a width of 750px (to speedup processing)
    # rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    rgb = imutils.resize(frame, width=750)

    if len(frames_batch) == 32 or (shape is not None and frame.shape != shape):
        print("Sending batch of frames to worker", len(frames_batch))
        pqueue.put(frames_batch)
        frames_batch = []

    frames_batch.append((frame_index, ms, rgb))
    shape = frame.shape

print("Sending last batch of frames to worker", len(frames_batch))
pqueue.put(frames_batch)

# Announce the workers the end of the work
for worker in workers:
    pqueue.put("DONE")

# close the video file pointers
stream.release()

# Wait for all workers to finish their job
for worker in workers:
    print("Waiting for worker to terminate...")
    worker.join()
print("All workers are finished!")



# Merge the data from all CSV files
combined = {}
for worker_index in range(len(workers)):
    f = open("output_worker_" + str(worker_index) + ".csv", "r")
    for line in f.readlines():
        [frame_index, found, ms] = line.strip().split(",")
        combined.setdefault(int(float(ms) / 1000), []).append( (int(float(ms)), True if found == "1" else False) )
    f.close()

# Compute the decision per second of the video about whether Tom Cruise is found in the second
f = open("final_output.csv", "w")
for second in sorted(combined.keys()):
    occurrences = combined[second]
    positive_occurrences_ms = [ ms for (ms, found) in occurrences if found ]
    min_ts_with_appearance = min(positive_occurrences_ms) if positive_occurrences_ms else 0
    f.write( str(second) + "," + str(int(len(positive_occurrences_ms) != 0)) + "," + str(min_ts_with_appearance/1000.0) + "\n")
f.close()


print("File processing took", time.time() - START_TS, "seconds")
