export FLASK_APP=server.py
flask run --with-threads
