# 1st argument: directory with pictures of the person to be recognized
# 2nd argument: directory containing the frames to be classified
face_recognition /mnt/dom/harry /mnt/dom/video2framesdownsample
