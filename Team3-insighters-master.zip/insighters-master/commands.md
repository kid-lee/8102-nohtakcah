# Commands

### Face Detection
* $ source env/bin/activate
* $ pip install -r requirements.txt
* $ git clone https://github.com/opencv/opencv.git
* $ python opencv/samples/python/facedetect.py --cascade opencv/data/haarcascades/haarcascade_frontalface_alt.xml --nested-cascade opencv/data/haarcascades/haarcascade_eye.xml

### Face recognisition
* ...