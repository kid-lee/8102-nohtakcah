# import required packages
import cv2
import dlib
import argparse
import time

# handle command line arguments
ap = argparse.ArgumentParser()
ap.add_argument('-w', '--weights', default='./models/mmod_human_face_detector.dat',
                help='path to weights file')
args = ap.parse_args()


align = openface.AlignDlib(args.dlibFacePredictor)


import glob
import os
input_files = glob.glob("../extract/*.png")
input_files.sort(key=lambda x: os.path.getmtime(x))
for f in input_files:
    bgrImg = cv2.imread(f)
    rgbImg = cv2.cvtColor(bgrImg, cv2.COLOR_BGR2RGB)
    # load input image
    bb = align.getAllFaceBoundingBoxes(rgbImg)

    if bb is None:
        # raise Exception("Unable to find a face: {}".format(imgPath))
        return None

    alignedFaces = []
    for box in bb:
        alignedFaces.append(
            align.align(
                args.imgDim,
                rgbImg,
                box,
                landmarkIndices=openface.AlignDlib.OUTER_EYES_AND_NOSE))

    if alignedFaces is None:
        raise Exception("Unable to align the frame")

    reps = []
    i = 0
    for alignedFace in alignedFaces:


#     image = face_recognition.load_image_file(f)
#     face_locations = face_recognition.face_locations(image, model="cnn")
#     print face_locations
