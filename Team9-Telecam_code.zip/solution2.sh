python pyannote-structure.py shot --verbose ../../pyannote-data/video1.mp4 \
                                      ../../pyannote-data/video1.shots.json

python pyannote-face.py track --verbose --every=0.5 ../../pyannote-data/video1.mp4 \
                                              ../../pyannote-data/video1.shots.json \
                                              ../../pyannote-data/video1.track.txt

python pyannote-face.py demo ../../pyannote-data/video1.mp4 \
                       ../../pyannote-data/video1.track.txt \
                       ../../pyannote-data/video1.track.mp4

python pyannote-face.py extract --verbose ../../pyannote-data/video1.mp4 \
                                    ../../pyannote-data/video1.track.txt \
                                    ../../dlib-models/shape_predictor_68_face_landmarks.dat \
                                    ../../dlib-models/dlib_face_recognition_resnet_model_v1.dat \
                                    ../../pyannote-data/video1.landmarks.txt \
                                    ../../pyannote-data/video1.embedding.txt


