import cv2
import dlib
import time
start = time.time()
import argparse
import os
import dlib
import sys

import numpy as np
import torch
from torch.autograd import Variable

np.set_printoptions(precision=2)
sys.path.insert(0, '/root/install/openface')
import openface
from PIL import Image
import loadOpenFace
import glob

sys.path.insert(0, './faiss')
import faiss
import pickle

fileDir = os.path.dirname(os.path.realpath(__file__))
modelDir = os.path.join(fileDir, '../../install/openface', 'models')
mlmodelDir = os.path.join(fileDir, 'models')
dlibModelDir = os.path.join(modelDir, 'dlib')
samplesDir = os.path.join(fileDir,'../downloads')
inDir = os.path.join(fileDir,'../extract')
outputDir = os.path.join(fileDir,'../output')
outputPDir = os.path.join(fileDir,'../output/positive')
outputNDir = os.path.join(fileDir,'../output/negtive')

def write_csv(data):
    f = open('../output/result.csv', 'w')
    f.write('Video time line (in Sec), Appearance\n')  # Give your csv text here.
    for d in data:
        f.write(data[0] + ',' + data[1] + '\n')
    f.close()

def torchImage(cv2_img):
    # img = cv2.cvtColor(cv2_img, cv2.COLOR_RGB2BGR)
    # img = cv2.resize(img, (96, 96), interpolation=cv2.INTER_LINEAR)
    img = np.transpose(cv2_img, (2, 0, 1))
    img = img.astype(np.float32) / 255.0
    I_ = torch.from_numpy(img).unsqueeze(0)
    # I_ = torch.cat(imgs, 0)
    I_ = Variable(I_, requires_grad=False)
    return I_

def localAverageTransform(cv_src):
    # scale = np.max(cv_src.shape) / 2
    # cv_src = cv2.addWeighted(cv_src, 4, cv2.GaussianBlur(cv_src, (0, 0), scale / 30), -4, 128)
    img_yuv = cv2.cvtColor(cv_src, cv2.COLOR_RGB2YUV)

    # equalize the histogram of the Y channel
    img_yuv[:, :, 0] = cv2.equalizeHist(img_yuv[:, :, 0])

    # convert the YUV image back to RGB format
    img_output = cv2.cvtColor(img_yuv, cv2.COLOR_YUV2BGR)
    return img_output
    # return  cv_src

def getRep(bgrImg, idx):
    if bgrImg is None:
        raise Exception("Unable to load image/frame")
    bgrImg = cv2.resize(bgrImg, (0,0), fx=0.5, fy=0.5)
    rgbImg = cv2.cvtColor(bgrImg, cv2.COLOR_BGR2RGB)

    # Get all bounding boxes
    bb = align.getAllFaceBoundingBoxes(rgbImg)

    if bb is None:
        # raise Exception("Unable to find a face: {}".format(imgPath))
        return None

    alignedFaces = []
    for box in bb:
        alignedFaces.append(
            align.align(
                args.imgDim,
                rgbImg,
                box,
                landmarkIndices=openface.AlignDlib.OUTER_EYES_AND_NOSE))

    if alignedFaces is None:
        raise Exception("Unable to align the frame")

    reps = []
    i = 0
    for alignedFace in alignedFaces:
        f = outputDir + "/" + idx + str(i) + ".jpg"
        i = i + 1
        alignedFace = localAverageTransform(alignedFace)
        # cv2.imwrite(f, cv2.cvtColor(alignedFace, cv2.COLOR_RGB2BGR))
        reps.append(net.forward(torchImage(alignedFace))[0])
        # reps.append(net.forward(alignedFace))
    return reps, bb, alignedFaces



if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument(
        '--dlibFacePredictor',
        type=str,
        help="Path to dlib's face predictor.",
        default=os.path.join(
            dlibModelDir,
            "shape_predictor_68_face_landmarks.dat"))

    # todo test other model to get better profile faces. https://towardsdatascience.com/cnn-based-face-detector-from-dlib-c3696195e01c
    parser.add_argument(
        '--networkModel',
        type=str,
        help="Path to Torch network model.",
        default='models/openface.nn4.small2.v1.t7')
    parser.add_argument('--threshold', type=float, default=0.5)
    parser.add_argument('--cuda', action='store_true')
    parser.add_argument('--imgDim', type=int,
                        help="Default image dimension.", default=96)
    parser.add_argument('--verbose', action='store_true')
    # models = loadModel()

    args = parser.parse_args()

    # face registration
    dimension = 128
    index = faiss.IndexFlatL2(dimension)  # build the index

    align = openface.AlignDlib(args.dlibFacePredictor)
    net = loadOpenFace.prepareOpenFace(useCuda=args.cuda)
    net = net.eval()
    net.cuda()

    # # caffe model
    # net = openface.TorchNeuralNet(
    #     args.networkModel,
    #     imgDim=args.imgDim,
    #     cuda=args.cuda)


    if os.path.exists('.registry.pkl'):
        with open('.registry.pkl', 'rb') as input:
            ar_data = pickle.load(input)
            # direct transfer of vector
            reader = faiss.VectorIOReader()
            faiss.copy_array_to_vector(ar_data, reader.data)
            index = faiss.read_index(reader)
            print 'reload registry from file'
    else:
        filenames = glob.glob(samplesDir + "/**/*.jpg")
        filenames.sort()
        for f in filenames:
            print f
            img = cv2.imread(f)
            reps, bb, faces = getRep(img, f.split('/')[-1])
            if len(reps) == 1:  # only keep images with single face for simplicity
                index.add(reps[0].cpu().detach().numpy())

        # todo serialise the registry in file and reload when required.
        writer = faiss.VectorIOWriter()
        faiss.write_index(index, writer)
        ar_data = faiss.vector_to_array(writer.data)
        with open('.registry.pkl', 'wb') as output:
            pickle.dump(ar_data, output, pickle.HIGHEST_PROTOCOL)
            print 'write registry to file'
            print('registry size: ' + str(index.ntotal))


    # getFaces()
    # findMatching(index)
    csvf = open('../output/tuning.csv', 'w')
    csvf.write('Video time line (in Sec), Appearance, f1,f2,f3,f4,f5,f6,f7,f8,f9,f10\n')  # Give your csv text here.

    csvf2 = open('../output/result.csv', 'w')
    csvf2.write('Video time line (in Sec), Appearance\n')  # Give your csv text here.

    input_files = glob.glob(inDir + "/*.png")
    input_files.sort(key=lambda x: os.path.getmtime(x))
    for f in input_files:
        print f
        second = f.split('/')[-1].split('.')[0]
        img = cv2.imread(f)
        reps, bb, faces = getRep(img, f.split('/')[-1])
        save = False
        csv_str = ''
        csv_str += f.split('/')[-1].split('.')[0] + ',' + ','
        csv_str2 = f.split('/')[-1].split('.')[0] + ','
        i = 0
        positive = False
        csv_str_list = []
        for rep in reps:
            rep = rep.cpu()
            k = 10  # we want to see 4 nearest neighbors
            D, I = index.search(rep.detach().numpy(), k)  # sanity check
            averge10 = sum(D[0]) / 10.0
            D, I = index.search(rep.detach().numpy(), 5)  # sanity check
            averge5 = sum(D[0]) / 5.0
            D, I = index.search(rep.detach().numpy(), 3)  # sanity check
            averge3 = sum(D[0]) / 3.0
            D, I = index.search(rep.detach().numpy(), 15)  # sanity check
            averge15 = sum(D[0]) / 15.0
            D, I = index.search(rep.detach().numpy(), 20)  # sanity check
            averge20 = sum(D[0]) / 20.0
            D, I = index.search(rep.detach().numpy(), 40)  # sanity check
            averge40 = sum(D[0]) / 40.0
            D, I = index.search(rep.detach().numpy(), 60)  # sanity check
            averge60 = sum(D[0]) / 60.0

            count = 0
            if averge3 < 1:
                count = count + 1
            if averge5 < 1:
                count = count + 1
            if averge10 < 1:
                count = count + 1
            if averge15 < 1:
                count = count + 1
            if averge20 < 1:
                count = count + 1
            if averge40 < 1:
                count = count + 1
            if averge60 < 1:
                count = count + 1
            if count > 4:
                positive |= True
            # if count >= 7: # add to knn
            #     index.add(rep.detach().numpy())

            csv_str_copy = csv_str
            csv_str_copy += str(averge3) + ',' + str(averge5) + ',' + str(averge10) + ',' + str(averge15) + ',' + str(averge20) + ',' + str(averge40) + ',' +str(averge60) + ',' + str(i)
            csv_str_list.append(csv_str_copy)
            # facef = outputDir + "/faces/" + second + "-" + str(i) + ".png"
            # cv2.imwrite(facef, cv2.cvtColor(faces[i], cv2.COLOR_RGB2BGR))

            i = i + 1

        if len(csv_str_list) == 0:
            csvf.write(csv_str + '\n')
        for l in csv_str_list:
            csvf.write(l + '\n')

        if positive:
            csvf2.write( csv_str2 + '1\n')
        else:
            csvf2.write(csv_str2 + '0\n')

    csvf.close()
    csvf2.close()


        # path = ''
        # if save:
        #     path = outputPDir + "/" + f.split('/')[-1]
        # else:
        #     path = outputNDir + "/" + f.split('/')[-1]
        # print path

    #

    #




print ("Done!")